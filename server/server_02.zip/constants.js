const ITEMS_IN_PAGE = 20;

module.exports = { ITEMS_IN_PAGE };
